import React from "react";

const PageLayout = () => {
  return <div>PageLayout</div>;
};

export default PageLayout;
